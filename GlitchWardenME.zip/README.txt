ModelEngine 4 / Minecraft Java 26.2

Copy plugins/ModelEngine/blueprints/asset_c89517720db045279ea8fb46f3d93d5b.bbmodel into your server. The original texture is embedded in the file.
Run /meg reload models to import it and generate the resource pack. Install the generated pack for testing or distribute it to players.
Preview: /meg summon asset_c89517720db045279ea8fb46f3d93d5b
This preview uses ModelEngine's default pig base entity. Bind the model to your intended entity in your server integration.

Attach in your own server plugin (Java, not a chat command):
With ModelEngine 4 installed and declared as a plugin dependency, run this once for an entity your plugin owns, after the blueprint has loaded. entity is your existing Bukkit entity.
var modeledEntity = ModelEngineAPI.getModeledEntity(entity);
if (modeledEntity == null) modeledEntity = ModelEngineAPI.createModeledEntity(entity);
var activeModel = ModelEngineAPI.createActiveModel("asset_c89517720db045279ea8fb46f3d93d5b");
modeledEntity.addModel(activeModel, true);

Playback keys (case-sensitive):
  "FurnaceGuardIdle"
To preview one saved clip on that activeModel:
activeModel.getAnimationHandler().playAnimation("FurnaceGuardIdle", 0.0, 0.0, 1.0, true);
This selects the first included clip for inspection only; choose gameplay events in your plugin.
Animation API: https://wiki.mythiccraft.io/modelengine/API/Basic/Play-Stop-Animation
Attachment API: https://wiki.mythiccraft.io/modelengine/API/Basic/Add-Remove-Model

The model retains source facing and size (16 model units per Minecraft block). Adjust scale, facing, hitboxes, AI and animation triggers for your server.
Plugin installation, resource-pack hosting and entity gameplay are not included.
https://wiki.mythiccraft.io/modelengine/Modeling/Importing-a-Model
FurnaceGuardIdle: Quaternion motion was converted to numeric ZYX keys with quarter-interval angular checks within 0.05 degrees. This is a sampled approximation; inspect continuous target playback.
Rounded source rotations were normalized. This is a bounded approximation; original source bytes are preserved. Details record local matrix differences, not a global vertex-error guarantee.
Import the .bbmodel into ModelEngine 4 and generate its resource pack. Source facing is retained; verify North-facing orientation, scale, materials and playback before binding entity behavior. Hitboxes, AI and native effects are not generated.

The original model, texture and saved motion/effect sources are retained under Source.
conversion.json describes this selected-version conversion. Test the result in your target game/mod/plugin.

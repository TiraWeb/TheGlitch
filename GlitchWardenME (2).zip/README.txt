Saved-version inventory package

model.blockymodel, texture.png and any Animations clips are copied unchanged
from this selected saved version. Inventory/menu images show its rest pose.
Existing clips are included separately; the directional sheet is static.
This download is a derived package, not a replacement for an older frozen
source export and not evidence of gameplay or requested motion quality.

Optional outlined UI icons

Icons/UI/icon_16_outline.png, icon_32_outline.png and icon_64_outline.png add a
one-pixel neutral light rim outside the visible silhouette for dark UI slots.
These companions use the same original geometry, atlas and camera, with a
one-pixel inset to leave room for the rim. The outside remains transparent;
interior color/alpha and enclosed transparent holes are preserved. The smaller
render can omit fine details, especially at 16 pixels. Compare the raw and
outlined versions in your actual UI. The raw Icons/icon_*.png files are unchanged.
Use 64 pixels or larger for detailed creatures; 16 pixels is a compact fallback
and may show only a general shape, even with the rim.
This is an optional UI contrast treatment, not a material or model alteration.

Inventory and menu images

model.blockymodel and texture.png are the original saved source bytes. These
images render that model's rest pose with its atlas, transparent background,
orthographic cameras and the Studio preview light. Fullbright faces retain
their painted color. Raw images have no added floor, labels, outline or materials.

Icons/icon_16.png, icon_32.png, icon_64.png, icon_128.png and icon_256.png:
inventory, hotbar and compact menu sizes. Each is rasterized at its own size
with the same three-quarter camera, nearest atlas texels and an 8% margin.
Choose the closest native size and use nearest-neighbor filtering/integer
scaling for crisp pixels. Tiny details can disappear at 16 or 32 pixels;
inspect the chosen size in your actual interface before shipping.

Menu/menu_512.png: larger menu portrait. Menu/menu_512.webp: lossless web/menu
companion with alpha. Icons/icon_128.tga: 32-bit RGBA editor/legacy companion.
PNG is the default game-art format; the other formats are optional imports.
thumbnail.png is the same three-quarter view as Icons/icon_256.png.

Views/front.png, side.png and back.png: 256-pixel orthographic references.
Front means looking toward -Z with +Y up; side is yaw +90 degrees. These are
coordinate labels, not a claim about the object's semantic front.

Sprites/directions.png: eight STATIC directional views in one horizontal
2048x256 PNG, in yaw order 0,45,90,135,180,225,270,315, all pitched 25 degrees.
Sprites/directions.json supplies frame rectangles, source-space center,
pixel pivots and the shared orthographic scale. It is a static turntable,
not a walking/character animation or a generated motion clip. Slice frames
without smoothing. One-sided surfaces are only visible from their authored
side; a transparent rear/edge view is preserved rather than invented.

Engine import notes

Hytale item definitions accept PNG Icon files in Common/Icons/ItemsGenerated
or Common/Icons/Items; model/NPC definitions use Common/Icons/ModelsGenerated
or Common/Icons/Models. Select and register the right image for your asset:
https://docs.hytale.com/assets/item/items/
https://docs.hytale.com/assets/models/

Minecraft Bedrock separates inventory/hotbar icons from the held model's
texture. Register an icon under textures/items and item_texture.json using
your own item definition; this bundle supplies no Bedrock model conversion:
https://learn.microsoft.com/en-us/minecraft/creator/documents/addcustomitems?view=minecraft-bedrock-stable

Luanti distinguishes inventory_image from wield_image. Choose the inventory
PNG in your item definition and decide separately how the held item renders:
https://api.luanti.org/definition-tables/
https://docs.luanti.org/for-creators/textures/

This is supporting art and editable source, not an installable or game-tested
pack. Engine resource paths, item definitions and gameplay require separate
integration. support.json binds every file to this exact model and atlas.

Minecraft Java 26.2

1. Put this ZIP in your resourcepacks folder.
2. Enable it under Options > Resource Packs.
3. With commands enabled, run:
/give @s minecraft:paper[minecraft:item_model="myrlin:asset_c89517720db045279ea8fb46f3d93d5b"]

The item uses paper's existing gameplay. This pack changes its model only when the item_model component selects it.

pack.png is the 128-pixel pack chooser image, rendered from this saved model and texture in its rest pose. Item inventory views still use the 3D model.

The model fits within one block and uses standard 3D inventory/hand display settings. Adjust display transforms in Blockbench for a specific grip or scale.

Conversion adjustments:
ChestL: rounded saved rotations required a small approximation; maximum corner movement 0.00000546536 native units. The original model and atlas are unchanged.
ChestR: rounded saved rotations required a small approximation; maximum corner movement 0.00000546536 native units. The original model and atlas are unchanged.
ShoulderL: rounded saved rotations required a small approximation; maximum corner movement 0.00000758077 native units. The original model and atlas are unchanged.
FistL: rounded saved rotations required a small approximation; maximum corner movement 2.68296e-7 native units. The original model and atlas are unchanged.
ShoulderR: rounded saved rotations required a small approximation; maximum corner movement 0.00000758077 native units. The original model and atlas are unchanged.
FistR: rounded saved rotations required a small approximation; maximum corner movement 2.68296e-7 native units. The original model and atlas are unchanged.
CheekIronL: rounded saved rotations required a small approximation; maximum corner movement 0.00000203880 native units. The original model and atlas are unchanged.
CheekIronR: rounded saved rotations required a small approximation; maximum corner movement 0.00000203880 native units. The original model and atlas are unchanged.
KneeL: rounded saved rotations required a small approximation; maximum corner movement 0.00000101055 native units. The original model and atlas are unchanged.
KneeR: rounded saved rotations required a small approximation; maximum corner movement 0.00000101055 native units. The original model and atlas are unchanged.

The original model, texture and saved motion/effect sources are retained under Source.
conversion.json describes this selected-version conversion. Test the result in your target game/mod/plugin.
